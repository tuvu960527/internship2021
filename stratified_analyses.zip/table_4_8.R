# import hypertension data
hyper <- read.csv("data_hypertension.csv")

# without cases hta at baseline
noncases <- subset(hyper, prevalent_hta=="0")

# Processed meat (servings/week)
noncases$pm_ser <- noncases$proc_meat/150

# Divide proc_meat into different subgroups
noncases$pm <- 0
for (i in 1:length(noncases$pm_ser)) {
  if (noncases$pm_ser[i] < 1) {
    noncases$pm[i] <- 1
  }
  else if (noncases$pm_ser[i] >= 1 && noncases$pm_ser[i] < 2) {
    noncases$pm[i] <- 2
  }
  else if (noncases$pm_ser[i] >= 2 && noncases$pm_ser[i] < 3) {
    noncases$pm[i] <- 3
  }
  else if (noncases$pm_ser[i] >= 3 && noncases$pm_ser[i] < 4) {
    noncases$pm[i] <- 4
  }
  else if (noncases$pm_ser[i] >= 4 && noncases$pm_ser[i] < 5) {
    noncases$pm[i] <- 5
  }
  else if (noncases$pm_ser[i] >= 5) {
    noncases$pm[i] <- 6
  }
}

# subgroup bmi (undernutrition, reference, overweight and obesity)
undernutrition <- subset(noncases, imcq3 < 18.5)
reference <- subset(noncases, imcq3 >= 18.5 & imcq3 < 25)
overweight <- subset(noncases, imcq3 >= 25 & imcq3 < 30)
obesity <- subset(noncases, imcq3 >= 30)

# subgroup smoking
exsmoking <- subset(noncases, tabacq3 == "X")
neversmoking <- subset(noncases, tabacq3 == "?" | tabacq3 == "." | tabacq3 == "NF")
smoking <- subset(noncases, tabacq3 == "F")

# subgroup education
# 0 - valeurs manquantes; 1 - n’a pas fait d’études ; 2 - obtention du certificat d’études ; 
# 3 - brevet d’études du premier cycle de second degré (BEPC) ou certificat d’aptitude professionnel (CAP) ;
# 4 - bac à bac+2 ; 5 - bac+3 à bac +4 ; 6 - au moins bac+5.
noneducation <- subset(noncases, bacfemme2 == 0 | bacfemme2 == 1)
highschool <- subset(noncases, bacfemme2 == 2 | bacfemme2 == 3)
college <- subset(noncases, bacfemme2 == 4 | bacfemme2 == 5 | bacfemme2 == 6)

# <= 3.5 METs and > 3.5 METs
sedentary <- subset(noncases, TotalAPQ3 <= 3.5)
active <- subset(noncases, TotalAPQ3 > 3.5)

# Family history cvd
non_famcvd <- subset(noncases, fam_cvd == 0)
famcvd <- subset(noncases, fam_cvd == 1)

# Family history hta
non_famhta <- subset(noncases, fam_hta == 0)
famhta <- subset(noncases, fam_hta == 1)

# Cox model
library("survival")
library("car")

# Models adjusted for BMI, total physical activity, smoking, family history of CVD, education level, 
# intake of alcohol and total calorific intake with age as the timeline, minus the stratification variable.

# Undernutrition 
undernutrition$SurvObj <- with(undernutrition, Surv(age_debut, age_hta, hypertension))
model1 <- coxph(SurvObj ~ factor(pm) + TotalAPQ3 + factor(tabacq3) + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = undernutrition)
summary(model1)

# Reference
reference$SurvObj <- with(reference, Surv(age_debut, age_hta, hypertension))
model2 <- coxph(SurvObj ~ factor(pm) + TotalAPQ3 + factor(tabacq3) + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = reference)
summary(model2)

# Overweight
overweight$SurvObj <- with(overweight, Surv(age_debut, age_hta, hypertension))
model3 <- coxph(SurvObj ~ factor(pm) + TotalAPQ3 + factor(tabacq3) + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = overweight)
summary(model3)

# Obesity
obesity$SurvObj <- with(obesity, Surv(age_debut, age_hta, hypertension))
model4 <- coxph(SurvObj ~ factor(pm) + TotalAPQ3 + factor(tabacq3) + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = obesity)
summary(model4)

# Ex smoking
exsmoking$SurvObj <- with(exsmoking, Surv(age_debut, age_hta, hypertension))
model5 <- coxph(SurvObj ~ factor(pm) + imcq3 + TotalAPQ3 + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = exsmoking)
summary(model5)

# Never smoking
neversmoking$SurvObj <- with(neversmoking, Surv(age_debut, age_hta, hypertension))
model6 <- coxph(SurvObj ~ factor(pm) + imcq3 + TotalAPQ3 + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = neversmoking)
summary(model6)

# Smoking
smoking$SurvObj <- with(smoking, Surv(age_debut, age_hta, hypertension))
model7 <- coxph(SurvObj ~ factor(pm) + imcq3 + TotalAPQ3 + factor(fam_cvd) + factor(fam_hta) +
                  factor(bacfemme2) + alcool + kcal, data = smoking)
summary(model7)

# Less than high school
noneducation$SurvObj <- with(noneducation, Surv(age_debut, age_hta, hypertension))
model8 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + TotalAPQ3 + factor(fam_cvd) + 
                  factor(fam_hta) + alcool + kcal, data = noneducation)
summary(model8)

# High school
highschool$SurvObj <- with(highschool, Surv(age_debut, age_hta, hypertension))
model9 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + TotalAPQ3 + factor(fam_cvd) + 
                  factor(fam_hta) + alcool + kcal, data = highschool)
summary(model9)

# College
college$SurvObj <- with(college, Surv(age_debut, age_hta, hypertension))
model10 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + TotalAPQ3 + factor(fam_cvd) + 
                  factor(fam_hta) + alcool + kcal, data = college)
summary(model10)

# <= 3.5 METs
sedentary$SurvObj <- with(sedentary, Surv(age_debut, age_hta, hypertension))
model11 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + factor(bacfemme2) + factor(fam_cvd) + 
                  factor(fam_hta) + alcool + kcal, data = sedentary)
summary(model11)

# > 3.5 METs
active$SurvObj <- with(active, Surv(age_debut, age_hta, hypertension))
model12 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + factor(bacfemme2) + factor(fam_cvd) + 
                   factor(fam_hta) + alcool + kcal, data = active)
summary(model12)

# Non family history of hypertension
non_famhta$SurvObj <- with(non_famhta, Surv(age_debut, age_hta, hypertension))
model13 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + factor(bacfemme2) + TotalAPQ3 + 
                   factor(fam_cvd) + alcool + kcal, data = non_famhta)
summary(model13)

# With family history of hypertension
famhta$SurvObj <- with(famhta, Surv(age_debut, age_hta, hypertension))
model14 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + factor(bacfemme2) + TotalAPQ3 + 
                   factor(fam_cvd) + alcool + kcal, data = famhta)
summary(model14)

# Non family history of cardiovascular disease
non_famcvd$SurvObj <- with(non_famcvd, Surv(age_debut, age_hta, hypertension))
model15 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + factor(bacfemme2) + TotalAPQ3 + 
                   factor(fam_hta) + alcool + kcal, data = non_famcvd)
summary(model15)

# Family history of cardiovascular disease
famcvd$SurvObj <- with(famcvd, Surv(age_debut, age_hta, hypertension))
model16 <- coxph(SurvObj ~ factor(pm) + imcq3 + factor(tabacq3) + factor(bacfemme2) + TotalAPQ3 + 
                   factor(fam_hta) + alcool + kcal, data = famcvd)
summary(model16)
