# import dyslipidemia data
dyslipidemia <- read.csv("data_dyslipidemia.csv")

# without cases hta at baseline
noncases <- subset(dyslipidemia, prev_dys == 0)

# Omit NA by column via is.na
nc <- noncases[!is.na(noncases$proc_meat), ]    

# Choice units (servings/week)
nc$pm_ser <- nc$proc_meat/150
nc$rm_ser <- nc$red_meat/150
nc$wm_ser <- nc$white_meat/150
nc$fish_ser <- nc$fish/150
nc$sf_ser <- nc$shellfish/150
nc$leg_ser <- nc$legumes/150
nc$pot_ser <- nc$potatoes/150
nc$fries_ser <- nc$fries/150
nc$eggs_ser <- nc$eggs/150
nc$rice_ser <- nc$rice/150
nc$ cer_ser <- nc$cereals/150
nc$dp_ser <- nc$dairy_products/150

# Divide proc_meat into different subgroups
nc$pm <- 0
for (i in 1:length(nc$pm_ser)) {
  if (nc$pm_ser[i] < 1) {
    nc$pm[i] <- 1
  }
  else if (nc$pm_ser[i] >= 1 && nc$pm_ser[i] < 2) {
    nc$pm[i] <- 2
  }
  else if (nc$pm_ser[i] >= 2 && nc$pm_ser[i] < 3) {
    nc$pm[i] <- 3
  }
  else if (nc$pm_ser[i] >= 3 && nc$pm_ser[i] < 4) {
    nc$pm[i] <- 4
  }
  else if (nc$pm_ser[i] >= 4 && nc$pm_ser[i] < 5) {
    nc$pm[i] <- 5
  }
  else if (nc$pm_ser[i] >= 5) {
    nc$pm[i] <- 6
  }
}

# Smoker
nc$smoker <- 0
nc$smoker[nc$tabacq3 == "F"] <- 1

# Cox model
library("survival")
library("car")

# Model 1 was adjusted for total energy 
nc$SurvObj <- with(nc, Surv(ageq3, agefin, trt_dysl))
model1 <- coxph(SurvObj ~  factor(pm) + kcal, data = nc)
summary(model1)

# Model 2 was adjusted adjust as M1 and for unmodified & modified risk factors
nc$SurvObj <- with(nc, Surv(ageq3, agefin, trt_dysl))
model2 <- coxph(SurvObj ~  factor(pm) + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3, data = nc)
summary(model2)

# Model 3 was adjusted adjust as M2 and imcq3
nc$SurvObj <- with(nc, Surv(ageq3, agefin, trt_dysl))
model3 <- coxph(SurvObj ~  factor(pm) + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3 + imcq3, data = nc)
summary(model3)

# Model 4: was adjusted adjust as M3 and red meat, white meat, fish, shellfish, legumes, potatoes, fries, eggs, rice, cereals and dairy products
nc$SurvObj <- with(nc, Surv(ageq3, agefin, trt_dysl))
model4 <- coxph(SurvObj ~  factor(pm) + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3 + imcq3 +
                  rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + cer_ser + dp_ser, data = nc)
summary(model4)
