hyper <- read.csv("data_hypertension.csv")

# Divide the data into 2 groups: non cases and with cases
# non cases (0) : group without prevalent of hypertension at baseline
# cases (1) : group with prevalent of hypertension at baseline
noncases <- subset(hyper, prevalent_hta == 0)

# Choice units (servings/week)
noncases$pm_ser <- noncases$proc_meat/150
noncases$rm_ser <- noncases$red_meat/150
noncases$wm_ser <- noncases$white_meat/150
noncases$fish_ser <- noncases$fish/150
noncases$sf_ser <- noncases$shellfish/150
noncases$leg_ser <- noncases$legumes/150
noncases$pot_ser <- noncases$potatoes/150
noncases$fries_ser <- noncases$fries/150
noncases$eggs_ser <- noncases$eggs/150
noncases$rice_ser <- noncases$rice/150
noncases$ cer_ser <- noncases$cereals/150
noncases$dp_ser <- noncases$dairy_products/150

# Divide proc_meat into different subgroups
noncases$pm <- 0
for (i in 1:length(noncases$pm_ser)) {
  if (noncases$pm_ser[i] < 1) {
    noncases$pm[i] <- 1
  }
  else if (noncases$pm_ser[i] >= 1 && noncases$pm_ser[i] < 2) {
    noncases$pm[i] <- 2
  }
  else if (noncases$pm_ser[i] >= 2 && noncases$pm_ser[i] < 3) {
    noncases$pm[i] <- 3
  }
  else if (noncases$pm_ser[i] >= 3 && noncases$pm_ser[i] < 4) {
    noncases$pm[i] <- 4
  }
  else if (noncases$pm_ser[i] >= 4 && noncases$pm_ser[i] < 5) {
    noncases$pm[i] <- 5
  }
  else if (noncases$pm_ser[i] >= 5) {
    noncases$pm[i] <- 6
  }
}

# Smoker
noncases$smoker <- 0
noncases$smoker[noncases$tabacq3 == "F"] <- 1

# Cox model
library("survival")
library("car")

# Model 1 was adjusted for total energy 
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1 <- coxph(SurvObj ~  factor(pm) + kcal, data = noncases)
summary(model1)

# Model 2 was adjusted adjust as M1 and for unmodified & modified risk factors
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2 <- coxph(SurvObj ~  factor(pm) + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2)

# Model 3 was adjusted adjust as M2 and imcq3
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model3 <- coxph(SurvObj ~  factor(pm) + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3)

# Model 4: was adjusted adjust as M3 and red meat, white meat, fish, shellfish, legumes, potatoes, fries, eggs, rice, cereals and dairy products
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model4 <- coxph(SurvObj ~  factor(pm) + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3 + imcq3 +
                rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + cer_ser + dp_ser, data = noncases)
summary(model4)
