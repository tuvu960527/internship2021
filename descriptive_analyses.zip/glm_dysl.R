dysl <- read.csv("data_dyslipidemia.csv")
View(dysl)

# Set the class of dyslipidemia prevalence as factor
dysl$prev_dys <- as.factor(dysl$prev_dys)

# Divide the data into 2 groups: non cases and with cases
# non cases (0) : group without prevalent of hypertension at baseline
# cases (1) : group with prevalent of hypertension at baseline
noncases <- subset(dysl, prev_dys == 0)
cases <- subset(dysl, prev_dys == 1)


# Descriptive analysis of 2 groups
summary(noncases)
summary(cases)

# Age at baseline
dysl$ageq3 <- as.numeric(dysl$ageq3)
glm_age <- glm(prev_dys ~ ageq3, data = dysl, family = 'binomial')
summary(glm_age)

# Total energy intake
dysl$kcal <- as.numeric(dysl$kcal)
glm_kcal <- glm(prev_dys ~ kcal, data = dysl, family = 'binomial')
summary(glm_kcal)

# Processed meat
dysl$proc_meat <- as.numeric(dysl$proc_meat)
glm_pm <- glm(prev_dys ~ proc_meat, data = dysl, family = 'binomial')
summary(glm_pm)

# Ham
dysl$ham <- as.numeric(dysl$ham)
glm_ham <- glm(prev_dys ~ ham, data = dysl, family = 'binomial')
summary(glm_ham)

# Sausages
dysl$sausages <- as.numeric(dysl$sausages)
glm_sausages <- glm(prev_dys ~ sausages, data = dysl, family = 'binomial')
summary(glm_sausages)

# Pate
dysl$pate <- as.numeric(dysl$pate)
glm_pate <- glm(prev_dys ~ pate, data = dysl, family = 'binomial')
summary(glm_pate)

# Unprocessed red meat
dysl$red_meat <- as.numeric(dysl$red_meat)
glm_rm <- glm(prev_dys ~ red_meat, data = dysl, family = 'binomial')
summary(glm_rm)

# Beef
dysl$beef <- as.numeric(dysl$beef)
glm_beef <- glm(prev_dys ~ beef, data = dysl, family = 'binomial')
summary(glm_beef)

# Unprocessed white meat
dysl$white_meat <- as.numeric(dysl$white_meat)
glm_wm <- glm(prev_dys ~ white_meat, data = dysl, family = 'binomial')
summary(glm_wm)

# Poultry
dysl$poultry <- as.numeric(dysl$poultry)
glm_poultry <- glm(prev_dys ~ poultry, data = dysl, family = 'binomial')
summary(glm_poultry)

# Pork
dysl$pork <- as.numeric(dysl$pork)
glm_pork <- glm(prev_dys ~ pork, data = dysl, family = 'binomial')
summary(glm_pork)

# Fish
dysl$fish <- as.numeric(dysl$fish)
glm_fish <- glm(prev_dys ~ fish, data = dysl, family = 'binomial')
summary(glm_fish)

# Shellfish
dysl$shellfish <- as.numeric(dysl$shellfish)
glm_sf <- glm(prev_dys ~ shellfish, data = dysl, family = 'binomial')
summary(glm_sf)

# Fresh legumes
dysl$legumes <- as.numeric(dysl$legumes)
glm_legumes <- glm(prev_dys ~ legumes, data = dysl, family = 'binomial')
summary(glm_legumes)

# Raw vegetables
dysl$raw_veg <- as.numeric(dysl$raw_veg)
glm_rawveg <- glm(prev_dys ~ raw_veg, data = dysl, family = 'binomial')
summary(glm_rawveg)

# Fruits
dysl$fruits <- as.numeric(dysl$fruits)
glm_fruits <- glm(prev_dys ~ fruits, data = dysl, family = 'binomial')
summary(glm_fruits)

# Potatoes
dysl$potatoes <- as.numeric(dysl$potatoes)
glm_potatoes <- glm(prev_dys ~ potatoes, data = dysl, family = 'binomial')
summary(glm_potatoes)

# Fries
dysl$fries <- as.numeric(dysl$fries)
glm_fries <- glm(prev_dys ~ fries, data = dysl, family = 'binomial')
summary(glm_fries)

# Eggs
dysl$eggs <- as.numeric(dysl$eggs)
glm_eggs <- glm(prev_dys ~ eggs, data = dysl, family = 'binomial')
summary(glm_eggs)

# Rice
dysl$rice <- as.numeric(dysl$rice)
glm_rice <- glm(prev_dys ~ rice, data = dysl, family = 'binomial')
summary(glm_rice)

# Cereals
dysl$cereals <- as.numeric(dysl$cereals)
glm_cer <- glm(prev_dys ~ cereals, data = dysl, family = 'binomial')
summary(glm_cer)

# Dairy products
dysl$dairy_products <- as.numeric(dysl$dairy_products)
glm_dp <- glm(prev_dys ~ dairy_products, data = dysl, family = 'binomial')
summary(glm_dp)

# Cheese
dysl$cheese <- as.numeric(dysl$cheese)
glm_cheese <- glm(prev_dys ~ cheese, data = dysl, family = 'binomial')
summary(glm_cheese)

# Yoghurts
dysl$yoghurts <- as.numeric(dysl$yoghurts)
glm_yo <- glm(prev_dys ~ yoghurts, data = dysl, family = 'binomial')
summary(glm_yo)

# Pastries
dysl$pastries <- as.numeric(dysl$pastries)
glm_pastries <- glm(prev_dys ~ pastries, data = dysl, family = 'binomial')
summary(glm_pastries)

# Chocolate
dysl$chocolate <- as.numeric(dysl$chocolate)
glm_choco <- glm(prev_dys ~ chocolate, data = dysl, family = 'binomial')
summary(glm_choco)

# Sweet drinks
dysl$sweet_drinks <- as.numeric(dysl$sweet_drinks)
glm_swd <- glm(prev_dys ~ sweet_drinks, data = dysl, family = 'binomial')
summary(glm_swd)

# Alcohol
dysl$alcool <- as.numeric(dysl$alcool)
glm_alcohol <- glm(prev_dys ~ alcool, data = dysl, family = 'binomial')
summary(glm_alcohol)

# Cafeine
dysl$cafeine <- as.numeric(dysl$cafeine)
glm_cafeine <- glm(prev_dys ~ cafeine, data = dysl, family = 'binomial')
summary(glm_cafeine)

# CHOL
dysl$CHOL <- as.numeric(dysl$CHOL)
glm_chol <- glm(prev_dys ~ CHOL, data = dysl, family = 'binomial')
summary(glm_chol)

# Salt
dysl$salt <- as.numeric(dysl$salt)
glm_salt <- glm(prev_dys ~ salt, data = dysl, family = 'binomial')
summary(glm_salt)

# Sugars
dysl$sugars <- as.numeric(dysl$sugars)
glm_sugars <- glm(prev_dys ~ sugars, data = dysl, family = 'binomial')
summary(glm_sugars)

# Added sugars
dysl$added_sugars <- as.numeric(dysl$added_sugars)
glm_adsug <- glm(prev_dys ~ added_sugars, data = dysl, family = 'binomial')
summary(glm_adsug)

# Const sugars
dysl$const_sugars <- as.numeric(dysl$const_sugars)
glm_cosug <- glm(prev_dys ~ const_sugars, data = dysl, family = 'binomial')
summary(glm_cosug)

# Fats
dysl$fats <- as.numeric(dysl$fats)
glm_fats <- glm(prev_dys ~ fats, data = dysl, family = 'binomial')
summary(glm_fats)

# Western diet
dysl$west <- as.numeric(dysl$west)
glm_west <- glm(prev_dys ~ west, data = dysl, family = 'binomial')
summary(glm_west)

# Mediterranean diet
dysl$med <- as.numeric(dysl$med)
glm_med <- glm(prev_dys ~ med, data = dysl, family = 'binomial')
summary(glm_med)

#imcq3
dysl$imcq3 <- as.numeric(dysl$imcq3)
glm_bmi<-glm(prev_dys ~ imcq3, data = dysl, family = 'binomial')
summary(glm_bmi)

#pe
dysl$TotalAPQ3 <- as.numeric(dysl$TotalAPQ3)
glm_pe<-glm(prev_dys ~ TotalAPQ3, data = dysl, family = 'binomial')
summary(glm_pe)

#0: missing, 1: pas d'études, 2: certificat d'études, 3: BEPC-CAP, 4: BAC ? BAC+2, 5: BAC+3 ? BAC+4ans, 6: Au moins BAC+5ans
# Divide education into 3 groups: non education, with certificate, college education

### Non education
# Percentage of non education of non cases group 
noncases$non_edu <- 0
noncases$non_edu[noncases$bacfemme2 == 0] <- 1
noncases$non_edu[noncases$bacfemme2 == 1] <- 1
non_edu0 = table(noncases$non_edu)
prop.table(non_edu0)

# Percentage of non education of cases group 
cases$non_edu <- 0
cases$non_edu[cases$bacfemme2 == 0] <- 1
cases$non_edu[cases$bacfemme2 == 1] <- 1
non_edu1 = table(cases$non_edu)
prop.table(non_edu1)

# Compare the difference of percentages of non education  between two groups
dysl$non_edu <- 0
dysl$non_edu[dysl$bacfemme2 == 0] <- 1
dysl$non_edu[dysl$bacfemme2 == 1] <- 1
table(dysl$non_edu)
glm_nonedu <- glm(prev_dys ~ non_edu, data = dysl, family = 'binomial')
summary(glm_nonedu)

# With certificate

# Percentage of with certificate of non cases group
noncases$certif <- 0
noncases$certif[noncases$bacfemme2 == 2] <- 1
noncases$certif[noncases$bacfemme2 == 3] <- 1
certif0 = table(noncases$certif)
prop.table(certif0)

# Percentage of with certificate of cases group
cases$certif <- 0
cases$certif[cases$bacfemme2 == 2] <- 1
cases$certif[cases$bacfemme2 == 3] <- 1
certif1 = table(cases$certif)
prop.table(certif1)

# Compare the difference of percentages of with certificate between two groups
dysl$certif <- 0
dysl$certif[dysl$bacfemme2 == 2] <- 1
dysl$certif[dysl$bacfemme2 == 3] <- 1
table(dysl$certif)
glm_certif <- glm(prev_dys ~ certif, data = dysl, family = 'binomial')
summary(glm_certif)

# College education

# Percentage of college education of non cases group
noncases$college <- 0
noncases$college[noncases$bacfemme2 == 4] <- 1
noncases$college[noncases$bacfemme2 == 5] <- 1
noncases$college[noncases$bacfemme2 == 6] <- 1
college0 = table(noncases$college)
prop.table(college0)

# Percentage of college education of cases group
cases$college <- 0
cases$college[cases$bacfemme2 == 4] <- 1
cases$college[cases$bacfemme2 == 5] <- 1
cases$college[cases$bacfemme2 == 6] <- 1
college1 = table(cases$college)
prop.table(college1)

# Compare the difference of percentages of college education between two groups
dysl$college_edu <- 0
dysl$college_edu[dysl$bacfemme2 == 4] <- 1
dysl$college_edu[dysl$bacfemme2 == 5] <- 1
dysl$college_edu[dysl$bacfemme2 == 6] <- 1
table(dysl$college_edu)
glm_college <- glm(prev_dys ~ college_edu, data = dysl, family = 'binomial')
summary(glm_college)

# current smoker percentage of non cases group
noncases$smoker <- 0
noncases$smoker[noncases$tabacq3 == "F"] <- 1
current_smoker0 = table(noncases$smoker)
prop.table(current_smoker0)

# current smoker percentage of cases group
cases$smoker <- 0
cases$smoker[cases$tabacq3 == "F"] <- 1
current_smoker1 = table(cases$smoker)
prop.table(current_smoker1)

# compare the percentage of current smoker between 2 groups
dysl$smoker <- 0
dysl$smoker[dysl$tabacq3 == "F"] <- 1
table(dysl$smoker)
glm_smoker <- glm(prev_dys ~ smoker, data = dysl, family = 'binomial')
summary(glm_smoker)

#fam_cvd

# Percentage of family history cvd of non cases group
noncases$fam_hist_cvd <- 0
noncases$fam_hist_cvd[noncases$fam_cvd == 1] <- 1
fh_cvd0 = table(noncases$fam_hist_cvd)
prop.table(fh_cvd0)

# Percentage of family history cvd of cases group
cases$fam_hist_cvd <- 0
cases$fam_hist_cvd[cases$fam_cvd == 1] <- 1
fh_cvd1 = table(cases$fam_hist_cvd)
prop.table(fh_cvd1)

# Compare the percentages of fam_cvd between 2 groups
dysl$fam_hist_cvd <- 0
dysl$fam_hist_cvd[dysl$fam_cvd == 1] <- 1
table(dysl$fam_hist_cvd)
glm_fcvd <- glm(prev_dys ~ fam_cvd, data = dysl, family = 'binomial')
summary(glm_fcvd)

#fam_hta
# Percentage of family history hta of non cases group
noncases$fam_hist_hta <- 0
noncases$fam_hist_hta[noncases$fam_hta == 1] <- 1
fam_hta0 = table(noncases$fam_hist_hta)
prop.table(fam_hta0)

# Percentage of family history hta of cases group
cases$fam_hist_hta <- 0
cases$fam_hist_hta[cases$fam_hta == 1] <- 1
fam_hta1 = table(cases$fam_hist_hta)
prop.table(fam_hta1)

# Compare the percentages of fam_hta between 2 groups
dysl$fam_hist_hta <- 0
dysl$fam_hist_hta[dysl$fam_hta == 1] <- 1
table(dysl$fam_hist_hta)
glm_fhta <- glm(prev_dys ~ fam_hta, data = dysl, family = 'binomial')
summary(glm_fhta)

# Cox model
library("survival")
library("car")
duration = noncases$agefin - noncases$ageq3
noncases$duration=duration

# create a survival object
noncases$SurvObj <- with(noncases, Surv(ageq3, agefin, diabete))
cox.model <- coxph(SurvObj ~ kcal + proc_meat + red_meat + white_meat + 
                     fish + shellfish + salad + legumes + raw_veg + fruits +
                     potatoes + fries + eggs + grains + dairy_products +
                     sweet_foods + sweet_drinks + alcool + cafeine + CHOL +
                     salt + sugars + added_sugars + const_sugars + fats +
                     west + med + bacfemme2 + fam_cvd + fam_hta + imcq3 + 
                     TotalAPQ3, data = noncases)
summary(cox.model)
