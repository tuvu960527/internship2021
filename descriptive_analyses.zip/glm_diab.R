# Import data of diabetes 
diabetes <- read.csv("data_diabetes.csv")


# Divide data into two groups
# non cases (0) : group without prevalent of diabetes at baseline
# cases (1) : group with prevalent of diabetes at baseline

noncases <- subset(diabetes, prev_diab == 0)
cases <- subset(diabetes, prev_diab == 1)

# Descriptive analysis of 2 groups
summary(noncases)
summary(cases)

# Age at baseline
diabetes$ageq3 <- as.numeric(diabetes$ageq3)
glm_age <- glm(prev_diab ~ ageq3, data = diabetes, family = 'binomial')
summary(glm_age)

# Total energy intake
diabetes$kcal <- as.numeric(diabetes$kcal)
glm_kcal <- glm(prev_diab ~ kcal, data = diabetes, family = 'binomial')
summary(glm_kcal)

# Processed meat
diabetes$proc_meat <- as.numeric(diabetes$proc_meat)
glm_pm <- glm(prev_diab ~ proc_meat, data = diabetes, family = 'binomial')
summary(glm_pm)

# Ham
diabetes$ham <- as.numeric(diabetes$ham)
glm_ham <- glm(prev_diab ~ ham, data = diabetes, family = 'binomial')
summary(glm_ham)

# Sausages
diabetes$sausages <- as.numeric(diabetes$sausages)
glm_sausages <- glm(prev_diab ~ sausages, data = diabetes, family = 'binomial')
summary(glm_sausages)

# Pate
diabetes$pate <- as.numeric(diabetes$pate)
glm_pate <- glm(prev_diab ~ pate, data = diabetes, family = 'binomial')
summary(glm_pate)

# Unprocessed red meat
diabetes$red_meat <- as.numeric(diabetes$red_meat)
glm_rm <- glm(prev_diab ~ red_meat, data = diabetes, family = 'binomial')
summary(glm_rm)

# Beef
diabetes$beef <- as.numeric(diabetes$beef)
glm_beef <- glm(prev_diab ~ beef, data = diabetes, family = 'binomial')
summary(glm_beef)

# Unprocessed white meat
diabetes$white_meat <- as.numeric(diabetes$white_meat)
glm_wm <- glm(prev_diab ~ white_meat, data = diabetes, family = 'binomial')
summary(glm_wm)

# Poultry
diabetes$poultry <- as.numeric(diabetes$poultry)
glm_poultry <- glm(prev_diab ~ poultry, data = diabetes, family = 'binomial')
summary(glm_poultry)

# Pork
diabetes$pork <- as.numeric(diabetes$pork)
glm_pork <- glm(prev_diab ~ pork, data = diabetes, family = 'binomial')
summary(glm_pork)


# Fish
diabetes$fish <- as.numeric(diabetes$fish)
glm_fish <- glm(prev_diab ~ fish, data = diabetes, family = 'binomial')
summary(glm_fish)

# Shellfish
diabetes$shellfish <- as.numeric(diabetes$shellfish)
glm_sf <- glm(prev_diab ~ shellfish, data = diabetes, family = 'binomial')
summary(glm_sf)

# Fresh legumes
diabetes$legumes <- as.numeric(diabetes$legumes)
glm_legumes <- glm(prev_diab ~ legumes, data = diabetes, family = 'binomial')
summary(glm_legumes)

# Raw vegetables
diabetes$raw_veg <- as.numeric(diabetes$raw_veg)
glm_rawveg <- glm(prev_diab ~ raw_veg, data = diabetes, family = 'binomial')
summary(glm_rawveg)

# Fruits
diabetes$fruits <- as.numeric(diabetes$fruits)
glm_fruits <- glm(prev_diab ~ fruits, data = diabetes, family = 'binomial')
summary(glm_fruits)

# Potatoes
diabetes$potatoes <- as.numeric(diabetes$potatoes)
glm_potatoes <- glm(prev_diab ~ potatoes, data = diabetes, family = 'binomial')
summary(glm_potatoes)

# Fries
diabetes$fries <- as.numeric(diabetes$fries)
glm_fries <- glm(prev_diab ~ fries, data = diabetes, family = 'binomial')
summary(glm_fries)

# Eggs
diabetes$eggs <- as.numeric(diabetes$eggs)
glm_eggs <- glm(prev_diab ~ eggs, data = diabetes, family = 'binomial')
summary(glm_eggs)

# Rice
diabetes$rice <- as.numeric(diabetes$rice)
glm_rice <- glm(prev_diab ~ rice, data = diabetes, family = 'binomial')
summary(glm_rice)

# Cereals
diabetes$cereals <- as.numeric(diabetes$cereals)
glm_cer <- glm(prev_diab ~ cereals, data = diabetes, family = 'binomial')
summary(glm_cer)

# Dairy products
diabetes$dairy_products <- as.numeric(diabetes$dairy_products)
glm_dp <- glm(prev_diab ~ dairy_products, data = diabetes, family = 'binomial')
summary(glm_dp)

# Cheese
diabetes$cheese <- as.numeric(diabetes$cheese)
glm_cheese <- glm(prev_diab ~ cheese, data = diabetes, family = 'binomial')
summary(glm_cheese)

# Yoghurts
diabetes$yoghurts <- as.numeric(diabetes$yoghurts)
glm_yo <- glm(prev_diab ~ yoghurts, data = diabetes, family = 'binomial')
summary(glm_yo)

# Pastries
diabetes$pastries <- as.numeric(diabetes$pastries)
glm_pastries <- glm(prev_diab ~ pastries, data = diabetes, family = 'binomial')
summary(glm_pastries)

# Chocolate
diabetes$chocolate <- as.numeric(diabetes$chocolate)
glm_choco <- glm(prev_diab ~ chocolate, data = diabetes, family = 'binomial')
summary(glm_choco)


# Sweet drinks
diabetes$sweet_drinks <- as.numeric(diabetes$sweet_drinks)
glm_swd <- glm(prev_diab ~ sweet_drinks, data = diabetes, family = 'binomial')
summary(glm_swd)

# Alcohol
diabetes$alcool <- as.numeric(diabetes$alcool)
glm_alcohol <- glm(prev_diab ~ alcool, data = diabetes, family = 'binomial')
summary(glm_alcohol)

# Cafeine
diabetes$cafeine <- as.numeric(diabetes$cafeine)
glm_cafeine <- glm(prev_diab ~ cafeine, data = diabetes, family = 'binomial')
summary(glm_cafeine)

# CHOL
diabetes$CHOL <- as.numeric(diabetes$CHOL)
glm_chol <- glm(prev_diab ~ CHOL, data = diabetes, family = 'binomial')
summary(glm_chol)

# Salt
diabetes$salt <- as.numeric(diabetes$salt)
glm_salt <- glm(prev_diab ~ salt, data = diabetes, family = 'binomial')
summary(glm_salt)

# Sugars
diabetes$sugars <- as.numeric(diabetes$sugars)
glm_sugars <- glm(prev_diab ~ sugars, data = diabetes, family = 'binomial')
summary(glm_sugars)

# Added sugars
diabetes$added_sugars <- as.numeric(diabetes$added_sugars)
glm_adsug <- glm(prev_diab ~ added_sugars, data = diabetes, family = 'binomial')
summary(glm_adsug)

# Const sugars
diabetes$const_sugars <- as.numeric(diabetes$const_sugars)
glm_cosug <- glm(prev_diab ~ const_sugars, data = diabetes, family = 'binomial')
summary(glm_cosug)

# Fats
diabetes$fats <- as.numeric(diabetes$fats)
glm_fats <- glm(prev_diab ~ fats, data = diabetes, family = 'binomial')
summary(glm_fats)

# Western diet
diabetes$west <- as.numeric(diabetes$west)
glm_west <- glm(prev_diab ~ west, data = diabetes, family = 'binomial')
summary(glm_west)

# Mediterranean diet
diabetes$med <- as.numeric(diabetes$med)
glm_med <- glm(prev_diab ~ med, data = diabetes, family = 'binomial')
summary(glm_med)

#imcq3
diabetes$imcq3 <- as.numeric(diabetes$imcq3)
glm_bmi<-glm(prev_diab ~ imcq3, data = diabetes, family = 'binomial')
summary(glm_bmi)

#pe
diabetes$TotalAPQ3 <- as.numeric(diabetes$TotalAPQ3)
glm_pe<-glm(prev_diab ~ TotalAPQ3, data = diabetes, family = 'binomial')
summary(glm_pe)

#0: missing, 1: pas d'études, 2: certificat d'études, 3: BEPC-CAP, 4: BAC ? BAC+2, 5: BAC+3 ? BAC+4ans, 6: Au moins BAC+5ans
# Divide education into 3 groups: non education, with certificate, college education

### Non education
# Percentage of non education of non cases group 
noncases$non_edu <- 0
noncases$non_edu[noncases$bacfemme2 == 0] <- 1
noncases$non_edu[noncases$bacfemme2 == 1] <- 1
non_edu0 = table(noncases$non_edu)
prop.table(non_edu0)

# Percentage of non education of cases group 
cases$non_edu <- 0
cases$non_edu[cases$bacfemme2 == 0] <- 1
cases$non_edu[cases$bacfemme2 == 1] <- 1
non_edu1 = table(cases$non_edu)
prop.table(non_edu1)

# Compare the difference of percentages of non education  between two groups
diabetes$non_edu <- 0
diabetes$non_edu[diabetes$bacfemme2 == 0] <- 1
diabetes$non_edu[diabetes$bacfemme2 == 1] <- 1
table(diabetes$non_edu)
glm_nonedu <- glm(prev_diab ~ non_edu, data = diabetes, family = 'binomial')
summary(glm_nonedu)

# With certificate

# Percentage of with certificate of non cases group
noncases$certif <- 0
noncases$certif[noncases$bacfemme2 == 2] <- 1
noncases$certif[noncases$bacfemme2 == 3] <- 1
certif0 = table(noncases$certif)
prop.table(certif0)

# Percentage of with certificate of cases group
cases$certif <- 0
cases$certif[cases$bacfemme2 == 2] <- 1
cases$certif[cases$bacfemme2 == 3] <- 1
certif1 = table(cases$certif)
prop.table(certif1)

# Compare the difference of percentages of with certificate between two groups
diabetes$certif <- 0
diabetes$certif[diabetes$bacfemme2 == 2] <- 1
diabetes$certif[diabetes$bacfemme2 == 3] <- 1
table(diabetes$certif)
glm_certif <- glm(prev_diab ~ certif, data = diabetes, family = 'binomial')
summary(glm_certif)

# College education

# Percentage of college education of non cases group
noncases$college <- 0
noncases$college[noncases$bacfemme2 == 4] <- 1
noncases$college[noncases$bacfemme2 == 5] <- 1
noncases$college[noncases$bacfemme2 == 6] <- 1
college0 = table(noncases$college)
prop.table(college0)

# Percentage of college education of cases group
cases$college <- 0
cases$college[cases$bacfemme2 == 4] <- 1
cases$college[cases$bacfemme2 == 5] <- 1
cases$college[cases$bacfemme2 == 6] <- 1
college1 = table(cases$college)
prop.table(college1)

# Compare the difference of percentages of college education between two groups
diabetes$college_edu <- 0
diabetes$college_edu[diabetes$bacfemme2 == 4] <- 1
diabetes$college_edu[diabetes$bacfemme2 == 5] <- 1
diabetes$college_edu[diabetes$bacfemme2 == 6] <- 1
table(diabetes$college_edu)
glm_college <- glm(prev_diab ~ college_edu, data = diabetes, family = 'binomial')
summary(glm_college)

# current smoker percentage of non cases group
noncases$smoker <- 0
noncases$smoker[noncases$tabacq3 == "F"] <- 1
current_smoker0 = table(noncases$smoker)
prop.table(current_smoker0)

# current smoker percentage of cases group
cases$smoker <- 0
cases$smoker[cases$tabacq3 == "F"] <- 1
current_smoker1 = table(cases$smoker)
prop.table(current_smoker1)

#current smoker
diabetes$smoker <- 0
diabetes$smoker[diabetes$tabacq3 == "F"] <- 1
table(diabetes$smoker)

glm_smoker <- glm(prev_diab ~ smoker, data = diabetes, family = 'binomial')
summary(glm_smoker)

#fam_cvd

# Percentage of family history cvd of non cases group
noncases$fam_hist_cvd <- 0
noncases$fam_hist_cvd[noncases$fam_cvd == 1] <- 1
fh_cvd0 = table(noncases$fam_hist_cvd)
prop.table(fh_cvd0)

# Percentage of family history cvd of cases group
cases$fam_hist_cvd <- 0
cases$fam_hist_cvd[cases$fam_cvd == 1] <- 1
fh_cvd1 = table(cases$fam_hist_cvd)
prop.table(fh_cvd1)

# Compare the percentages of fam_cvd between 2 groups
diabetes$fam_hist_cvd <- 0
diabetes$fam_hist_cvd[diabetes$fam_cvd == 1] <- 1
table(diabetes$fam_hist_cvd)
glm_fcvd <- glm(prev_diab ~ fam_cvd, data = diabetes, family = 'binomial')
summary(glm_fcvd)

#fam_hta
# Percentage of family history hta of non cases group
noncases$fam_hist_hta <- 0
noncases$fam_hist_hta[noncases$fam_hta == 1] <- 1
fam_hta0 = table(noncases$fam_hist_hta)
prop.table(fam_hta0)

# Percentage of family history hta of cases group
cases$fam_hist_hta <- 0
cases$fam_hist_hta[cases$fam_hta == 1] <- 1
fam_hta1 = table(cases$fam_hist_hta)
prop.table(fam_hta1)

# Compare the percentages of fam_hta between 2 groups
diabetes$fam_hist_hta <- 0
diabetes$fam_hist_hta[diabetes$fam_hta == 1] <- 1
table(diabetes$fam_hist_hta)
glm_fhta <- glm(prev_diab ~ fam_hta, data = diabetes, family = 'binomial')
summary(glm_fhta)

# Set the class of education as factor
noncases$bacfemme2 <- as.factor(noncases$bacfemme2)

# Set the class of smoker as factor
noncases$tabacq3 <- as.factor(noncases$tabacq3)

# Set age_hta as numeric
noncases$age_hta <- as.numeric(noncases$age_hta)

# Set age_debut as numeric
noncases$age_debut <- as.numeric(noncases$age_debut)

# Set fam_cvd as factor
noncases$fam_cvd <- as.factor(noncases$fam_cvd)

# Set fam_hta as factor
noncases$fam_hta <- as.factor(noncases$fam_hta)

# Divide proc_meat into subgroups
for (i in 1:length(noncases$proc_meat)) {
  if (noncases$proc_meat[i] < 50) {
    noncases$pm[i] <- 1
  }
  if (noncases$proc_meat[i] >= 50 && noncases$proc_meat[i] < 100) {
    noncases$pm[i] <- 2
  }
  if (noncases$proc_meat[i] >= 100 && noncases$proc_meat[i] < 150) {
    noncases$pm[i] <- 3
  }
  if (noncases$proc_meat[i] >= 150 && noncases$proc_meat[i] < 200) {
    noncases$pm[i] <- 4
  }
  if (noncases$proc_meat[i] >=200 && noncases$proc_meat[i] <=250) {
    noncases$pm[i] <- 5
  }
  if (noncases$proc_meat[i] > 250) {
    noncases$pm[i] <- 6
  }
}

# Divide legumes into subgroups
for (i in 1:length(noncases$fish)) {
  if (noncases$fish[i] < 50) {
    noncases$fi[i] <- 1
  }
  if (noncases$fish[i] >= 50 && noncases$fish[i] < 100) {
    noncases$fi[i] <- 2
  }
  if (noncases$fish[i] >= 100 && noncases$fish[i] < 150) {
    noncases$fi[i] <- 3
  }
  if (noncases$fish[i] >= 150 && noncases$fish[i] < 200) {
    noncases$fi[i] <- 4
  }
  if (noncases$fish[i] >=200 && noncases$fish[i] <=250) {
    noncases$fi[i] <- 5
  }
  if (noncases$fish[i] > 250) {
    noncases$fi[i] <- 6
  }
}

### change units
noncases$alcool = noncases$alcool * 7
noncases$cafeine = noncases$cafeine * 0.001 * 7
noncases$red_meat = noncases$red_meat * 7
noncases$white_meat = noncases$white_meat * 7
noncases$fish = noncases$fish * 7
noncases$shellfish = noncases$shellfish * 7
noncases$legumes = noncases$legumes * 7
noncases$raw_veg = noncases$raw_veg * 7
noncases$salad = noncases$fruits * 7
noncases$potatoes = noncases$potatoes * 7
noncases$fries = noncases$fries * 7
noncases$dairy_products = noncases$dairy_products * 7
noncases$sweet_foods = noncases$sweet_foods * 7
noncases$salt = noncases$salt * 7 * 0.001


# Set pm, rm and wm as factor
noncases$pm <- as.factor(noncases$pm)
noncases$fi <- as.factor(noncases$fi)

# Cox model
library("survival")
library("car")
year = noncases$age_diab - noncases$ageq3
noncases$year=year

## Non specific (processed meat)
### Model 1 was adjusted for family history cvd, family history hta and total energy intake.
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1 <- coxph(SurvObj ~ pm + fam_cvd + fam_hta + kcal, data = noncases)
summary(model1)
#anova(model1,type="chisq")

### Model 2 was adjusted for education, smoking, alcohol, caffeine, physical activity, body mass index
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2 <- coxph(SurvObj ~ pm + bacfemme2 + tabacq3 + alcool + cafeine + TotalAPQ3 + imcq3, data = noncases)
summary(model2)
#anova(model2,type="chisq")

### Model 3 was adjusted for red meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3 <- coxph(SurvObj ~ pm + red_meat, data = noncases)
summary(model3)

### Model 4 was adjusted for white meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4 <- coxph(SurvObj ~ pm + white_meat, data = noncases)
summary(model4)

### Model 5 was adjusted for shellfish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model5 <- coxph(SurvObj ~ pm + shellfish, data = noncases)
summary(model5)

### Model 6 was adjusted for sweet_foods and sweet_drinks
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model6 <- coxph(SurvObj ~ pm + sweet_foods + sweet_drinks, data = noncases)
summary(model6)

### Model 7 was adjusted for legumes, raw_veg, salad, fruits, potatoes, fries, dairy_products, salt
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model7 <- coxph(SurvObj ~ pm + legumes + raw_veg + salad + fruits + potatoes + fries + dairy_products + salt, data = noncases)
summary(model7)

## Non specific (fish)
### Model 1a was adjusted for family history cvd, family history hta and total energy intake.
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1a <- coxph(SurvObj ~ fi + fam_cvd + fam_hta + kcal, data = noncases)
summary(model1a)
#anova(model1,type="chisq")

### Model 2a was adjusted for education, smoking, alcohol, caffeine, physical activity, body mass index
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2a <- coxph(SurvObj ~ fi + bacfemme2 + tabacq3 + alcool + cafeine + TotalAPQ3 + imcq3, data = noncases)
summary(model2a)
#anova(model2,type="chisq")

### Model 3a was adjusted for red meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3a <- coxph(SurvObj ~ fi + red_meat, data = noncases)
summary(model3a)

### Model 4a was adjusted for white meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4a <- coxph(SurvObj ~ fi + white_meat, data = noncases)
summary(model4a)

### Model 5a was adjusted for shellfish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model5a <- coxph(SurvObj ~ fi + shellfish, data = noncases)
summary(model5a)

### Model 6a was adjusted for sweet_foods and sweet_drinks
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model6a <- coxph(SurvObj ~ fi + sweet_foods + sweet_drinks, data = noncases)
summary(model6a)

### Model 7a was adjusted for legumes, raw_veg, salad, fruits, potatoes, fries, dairy_products and salt
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model7a <- coxph(SurvObj ~ fi + legumes + raw_veg + salad + fruits + potatoes + fries + dairy_products + salt, data = noncases)
summary(model7a)

### Food substitution model
noncases$pm_servings <- noncases$proc_meat/50
noncases$fish_servings <- noncases$fish/50
### Model 1sub was adjusted for family history cvd, family history hta and total energy intake.

### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1sub <- coxph(SurvObj ~ pm_servings + fam_cvd + fam_hta + kcal, data = noncases)
summary(model1sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1asub <- coxph(SurvObj ~ fish_servings + fam_cvd + fam_hta + kcal, data = noncases)
summary(model1asub)

### Model 2sub was adjusted for education, smoking, alcohol, caffeine, physical activity, body mass index

### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2sub <- coxph(SurvObj ~ pm_servings + bacfemme2 + tabacq3 + alcool + cafeine + TotalAPQ3 + imcq3, data = noncases)
summary(model2sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2asub <- coxph(SurvObj ~ fish_servings + bacfemme2 + tabacq3 + alcool + cafeine + TotalAPQ3 + imcq3, data = noncases)
summary(model2asub)

### Model 3sub was adjusted for red meat

### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3sub <- coxph(SurvObj ~ pm_servings + red_meat, data = noncases)
summary(model3sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3asub <- coxph(SurvObj ~ fish_servings + red_meat, data = noncases)
summary(model3asub)

### Model 4sub was adjusted for white meat

### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4sub <- coxph(SurvObj ~ pm_servings + white_meat, data = noncases)
summary(model4sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4asub <- coxph(SurvObj ~ fish_servings + white_meat, data = noncases)
summary(model4asub)

### Model 5sub was adjusted for shellfish

### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model5sub <- coxph(SurvObj ~ pm_servings + shellfish, data = noncases)
summary(model5sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model5asub <- coxph(SurvObj ~ fish_servings + shellfish, data = noncases)
summary(model5asub)

### Model 6sub was adjusted for sweet_foods and sweet_drinks
### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model6sub <- coxph(SurvObj ~ pm_servings + sweet_foods + sweet_drinks, data = noncases)
summary(model6sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model6asub <- coxph(SurvObj ~ fish_servings + sweet_foods + sweet_drinks, data = noncases)
summary(model6asub)


### ### Model 7a was adjusted for legumes, raw_veg, salad, fruits, potatoes, fries, dairy_products and salt


### Processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model7sub <- coxph(SurvObj ~ pm_servings + legumes + raw_veg + salad + fruits + potatoes + fries + dairy_products + salt, data = noncases)
summary(model7sub)

### Fish
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model7asub <- coxph(SurvObj ~ fish_servings + legumes + raw_veg + salad + fruits + potatoes + fries + dairy_products + salt, data = noncases)
summary(model7asub)

