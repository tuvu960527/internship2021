hyper <- read.csv("data_hypertension.csv")

# Divide the data into 2 groups: non cases and with cases
# non cases (0) : group without prevalent of hypertension at baseline
# cases (1) : group with prevalent of hypertension at baseline
noncases <- subset(hyper, prevalent_hta == 0)
cases <- subset(hyper, prevalent_hta == 1)

# Descriptive analysis of 2 groups
summary(noncases)
summary(cases)

# Age at baseline
hyper$ageq3 <- as.numeric(hyper$ageq3)
glm_age <- glm(prevalent_hta ~ ageq3, data = hyper, family = 'binomial')
summary(glm_age)

# Total energy intake
hyper$kcal <- as.numeric(hyper$kcal)
glm_kcal <- glm(prevalent_hta ~ kcal, data = hyper, family = 'binomial')
summary(glm_kcal)

# Processed meat
hyper$proc_meat <- as.numeric(hyper$proc_meat)
glm_pm <- glm(prevalent_hta ~ proc_meat, data = hyper, family = 'binomial')
summary(glm_pm)

# Ham
hyper$ham <- as.numeric(hyper$ham)
glm_ham <- glm(prevalent_hta ~ ham, data = hyper, family = 'binomial')
summary(glm_ham)

# Sausages
hyper$sausages <- as.numeric(hyper$sausages)
glm_sausages <- glm(prevalent_hta ~ sausages, data = hyper, family = 'binomial')
summary(glm_sausages)

# Pate
hyper$pate <- as.numeric(hyper$pate)
glm_pate <- glm(prevalent_hta ~ pate, data = hyper, family = 'binomial')
summary(glm_pate)

# Unprocessed red meat
hyper$red_meat <- as.numeric(hyper$red_meat)
glm_rm <- glm(prevalent_hta ~ red_meat, data = hyper, family = 'binomial')
summary(glm_rm)

# Beef
hyper$beef <- as.numeric(hyper$beef)
glm_beef <- glm(prevalent_hta ~ beef, data = hyper, family = 'binomial')
summary(glm_beef)

# Unprocessed white meat
hyper$white_meat <- as.numeric(hyper$white_meat)
glm_wm <- glm(prevalent_hta ~ white_meat, data = hyper, family = 'binomial')
summary(glm_wm)

# Poultry
hyper$poultry <- as.numeric(hyper$poultry)
glm_poultry <- glm(prevalent_hta ~ poultry, data = hyper, family = 'binomial')
summary(glm_poultry)

# Pork
hyper$pork <- as.numeric(hyper$pork)
glm_pork <- glm(prevalent_hta ~ pork, data = hyper, family = 'binomial')
summary(glm_pork)

# Fish
hyper$fish <- as.numeric(hyper$fish)
glm_fish <- glm(prevalent_hta ~ fish, data = hyper, family = 'binomial')
summary(glm_fish)

# Shellfish
hyper$shellfish <- as.numeric(hyper$shellfish)
glm_sf <- glm(prevalent_hta ~ shellfish, data = hyper, family = 'binomial')
summary(glm_sf)


# Fresh legumes
hyper$legumes <- as.numeric(hyper$legumes)
glm_legumes <- glm(prevalent_hta ~ legumes, data = hyper, family = 'binomial')
summary(glm_legumes)

# Raw vegetables
hyper$raw_veg <- as.numeric(hyper$raw_veg)
glm_rawveg <- glm(prevalent_hta ~ raw_veg, data = hyper, family = 'binomial')
summary(glm_rawveg)

# Fruits
hyper$fruits <- as.numeric(hyper$fruits)
glm_fruits <- glm(prevalent_hta ~ fruits, data = hyper, family = 'binomial')
summary(glm_fruits)

# Potatoes
hyper$potatoes <- as.numeric(hyper$potatoes)
glm_potatoes <- glm(prevalent_hta ~ potatoes, data = hyper, family = 'binomial')
summary(glm_potatoes)

# Fries
hyper$fries <- as.numeric(hyper$fries)
glm_fries <- glm(prevalent_hta ~ fries, data = hyper, family = 'binomial')
summary(glm_fries)

# Eggs
hyper$eggs <- as.numeric(hyper$eggs)
glm_eggs <- glm(prevalent_hta ~ eggs, data = hyper, family = 'binomial')
summary(glm_eggs)

# Rice
hyper$rice <- as.numeric(hyper$rice)
glm_rice <- glm(prevalent_hta ~ rice, data = hyper, family = 'binomial')
summary(glm_rice)

# Cereals
hyper$cereals <- as.numeric(hyper$cereals)
glm_cer <- glm(prevalent_hta ~ cereals, data = hyper, family = 'binomial')
summary(glm_cer)

# Dairy products
hyper$dairy_products <- as.numeric(hyper$dairy_products)
glm_dp <- glm(prevalent_hta ~ dairy_products, data = hyper, family = 'binomial')
summary(glm_dp)

# Cheese
hyper$cheese <- as.numeric(hyper$cheese)
glm_cheese <- glm(prevalent_hta ~ cheese, data = hyper, family = 'binomial')
summary(glm_cheese)

# Yoghurts
hyper$yoghurts <- as.numeric(hyper$yoghurts)
glm_yo <- glm(prevalent_hta ~ yoghurts, data = hyper, family = 'binomial')
summary(glm_yo)

# Pastries
hyper$pastries <- as.numeric(hyper$pastries)
glm_pastries <- glm(prevalent_hta ~ pastries, data = hyper, family = 'binomial')
summary(glm_pastries)

# Chocolate
hyper$chocolate <- as.numeric(hyper$chocolate)
glm_choco <- glm(prevalent_hta ~ chocolate, data = hyper, family = 'binomial')
summary(glm_choco)

# Sweet drinks
hyper$sweet_drinks <- as.numeric(hyper$sweet_drinks)
glm_swd <- glm(prevalent_hta ~ sweet_drinks, data = hyper, family = 'binomial')
summary(glm_swd)

# Alcohol
hyper$alcool <- as.numeric(hyper$alcool)
glm_alcohol <- glm(prevalent_hta ~ alcool, data = hyper, family = 'binomial')
summary(glm_alcohol)

# Cafeine
hyper$cafeine <- as.numeric(hyper$cafeine)
glm_cafeine <- glm(prevalent_hta ~ cafeine, data = hyper, family = 'binomial')
summary(glm_cafeine)

# CHOL
hyper$CHOL <- as.numeric(hyper$CHOL)
glm_chol <- glm(prevalent_hta ~ CHOL, data = hyper, family = 'binomial')
summary(glm_chol)

# Salt
hyper$salt <- as.numeric(hyper$salt)
glm_salt <- glm(prevalent_hta ~ salt, data = hyper, family = 'binomial')
summary(glm_salt)

# Sugars
hyper$sugars <- as.numeric(hyper$sugars)
glm_sugars <- glm(prevalent_hta ~ sugars, data = hyper, family = 'binomial')
summary(glm_sugars)

# Added sugars
hyper$added_sugars <- as.numeric(hyper$added_sugars)
glm_adsug <- glm(prevalent_hta ~ added_sugars, data = hyper, family = 'binomial')
summary(glm_adsug)

# Const sugars
hyper$const_sugars <- as.numeric(hyper$const_sugars)
glm_cosug <- glm(prevalent_hta ~ const_sugars, data = hyper, family = 'binomial')
summary(glm_cosug)

# Fats
hyper$fats <- as.numeric(hyper$fats)
glm_fats <- glm(prevalent_hta ~ fats, data = hyper, family = 'binomial')
summary(glm_fats)

# Western diet
hyper$west <- as.numeric(hyper$west)
glm_west <- glm(prevalent_hta ~ west, data = hyper, family = 'binomial')
summary(glm_west)

# Mediterranean diet
hyper$med <- as.numeric(hyper$med)
glm_med <- glm(prevalent_hta ~ med, data = hyper, family = 'binomial')
summary(glm_med)

#imcq3
hyper$imcq3 <- as.numeric(hyper$imcq3)
glm_bmi<-glm(prevalent_hta ~ imcq3, data = hyper, family = 'binomial')
summary(glm_bmi)

#pe
hyper$TotalAPQ3 <- as.numeric(hyper$TotalAPQ3)
glm_pe<-glm(prevalent_hta ~ TotalAPQ3, data = hyper, family = 'binomial')
summary(glm_pe)

#0: missing, 1: pas d'études, 2: certificat d'études, 3: BEPC-CAP, 4: BAC ? BAC+2, 5: BAC+3 ? BAC+4ans, 6: Au moins BAC+5ans
# Divide education into 3 groups: non education, with certificate, college education

noncases$bacfemme2 <- as.factor(noncases$bacfemme2)
cases$bacfemme2 <- as.factor(cases$bacfemme2)

### Non education
# Percentage of non education of non cases group 
noncases$non_edu <- 0
noncases$non_edu[noncases$bacfemme2 == 0] <- 1
noncases$non_edu[noncases$bacfemme2 == 1] <- 1
non_edu0 = table(noncases$non_edu)
prop.table(non_edu0)

# Percentage of non education of cases group 
cases$non_edu <- 0
cases$non_edu[cases$bacfemme2 == 0] <- 1
cases$non_edu[cases$bacfemme2 == 1] <- 1
non_edu1 = table(cases$non_edu)
prop.table(non_edu1)

# Compare the difference of percentages of non education  between two groups
hyper$non_edu <- 0
hyper$non_edu[hyper$bacfemme2 == 0] <- 1
hyper$non_edu[hyper$bacfemme2 == 1] <- 1
table(hyper$non_edu)
glm_nonedu <- glm(prevalent_hta ~ non_edu, data = hyper, family = 'binomial')
summary(glm_nonedu)

# With certificate

# Percentage of with certificate of non cases group
noncases$certif <- 0
noncases$certif[noncases$bacfemme2 == 2] <- 1
noncases$certif[noncases$bacfemme2 == 3] <- 1
certif0 = table(noncases$certif)
prop.table(certif0)

# Percentage of with certificate of cases group
cases$certif <- 0
cases$certif[cases$bacfemme2 == 2] <- 1
cases$certif[cases$bacfemme2 == 3] <- 1
certif1 = table(cases$certif)
prop.table(certif1)

# Compare the difference of percentages of with certificate between two groups
hyper$certif <- 0
hyper$certif[hyper$bacfemme2 == 2] <- 1
hyper$certif[hyper$bacfemme2 == 3] <- 1
table(hyper$certif)
glm_certif <- glm(prevalent_hta ~ certif, data = hyper, family = 'binomial')
summary(glm_certif)

# College education

# Percentage of college education of non cases group
noncases$college <- 0
noncases$college[noncases$bacfemme2 == 4] <- 1
noncases$college[noncases$bacfemme2 == 5] <- 1
noncases$college[noncases$bacfemme2 == 6] <- 1
college0 = table(noncases$college)
prop.table(college0)

# Percentage of college education of cases group
cases$college <- 0
cases$college[cases$bacfemme2 == 4] <- 1
cases$college[cases$bacfemme2 == 5] <- 1
cases$college[cases$bacfemme2 == 6] <- 1
college1 = table(cases$college)
prop.table(college1)

# Compare the difference of percentages of college education between two groups
hyper$college_edu <- 0
hyper$college_edu[hyper$bacfemme2 == 4] <- 1
hyper$college_edu[hyper$bacfemme2 == 5] <- 1
hyper$college_edu[hyper$bacfemme2 == 6] <- 1
table(hyper$college_edu)
glm_college <- glm(prevalent_hta ~ college_edu, data = hyper, family = 'binomial')
summary(glm_college)

noncases$smoker <- as.factor(noncases$tabacq3)
cases$smoker <- as.factor(cases$tabacq3)
# current smoker percentage of non cases group
noncases$smoker <- 0
noncases$smoker[noncases$tabacq3 == "F"] <- 1
current_smoker0 = table(noncases$smoker)
prop.table(current_smoker0)

# current smoker percentage of cases group
cases$smoker <- 0
cases$smoker[cases$tabacq3 == "F"] <- 1
current_smoker1 = table(cases$smoker)
prop.table(current_smoker1)

#current smoker
hyper$smoker <- 0
hyper$smoker[hyper$tabacq3 == "F"] <- 1
table(hyper$smoker)

glm_smoker <- glm(prevalent_hta ~ smoker, data = hyper, family = 'binomial')
summary(glm_smoker)

#fam_cvd
noncases$fam_cvd <- as.factor(noncases$fam_cvd)
cases$fam_cvd <- as.factor(cases$fam_cvd)

# Percentage of family history cvd of non cases group
noncases$fam_hist_cvd <- 0
noncases$fam_hist_cvd[noncases$fam_cvd == 1] <- 1
fh_cvd0 = table(noncases$fam_hist_cvd)
prop.table(fh_cvd0)

# Percentage of family history cvd of cases group
cases$fam_hist_cvd <- 0
cases$fam_hist_cvd[cases$fam_cvd == 1] <- 1
fh_cvd1 = table(cases$fam_hist_cvd)
prop.table(fh_cvd1)

# Compare the percentages of fam_cvd between 2 groups
hyper$fam_hist_cvd <- 0
hyper$fam_hist_cvd[hyper$fam_cvd == 1] <- 1
table(hyper$fam_hist_cvd)
glm_fcvd <- glm(prevalent_hta ~ fam_cvd, data = hyper, family = 'binomial')
summary(glm_fcvd)

#fam_hta
noncases$fam_hta <- as.factor(noncases$fam_hta)
cases$fam_hta <- as.factor(cases$fam_hta)

# Percentage of family history hta of non cases group
noncases$fam_hist_hta <- 0
noncases$fam_hist_hta[noncases$fam_hta == 1] <- 1
fam_hta0 = table(noncases$fam_hist_hta)
prop.table(fam_hta0)

# Percentage of family history hta of cases group
cases$fam_hist_hta <- 0
cases$fam_hist_hta[cases$fam_hta == 1] <- 1
fam_hta1 = table(cases$fam_hist_hta)
prop.table(fam_hta1)

# Compare the percentages of fam_hta between 2 groups
hyper$fam_hist_hta <- 0
hyper$fam_hist_hta[hyper$fam_hta == 1] <- 1
table(hyper$fam_hist_hta)
glm_fhta <- glm(prevalent_hta ~ fam_hta, data = hyper, family = 'binomial')
summary(glm_fhta)








