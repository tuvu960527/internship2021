# Import hypertension data
hyper <- read.csv("data_hypertension.csv")
noncases <- subset(hyper, prevalent_hta == 0)
View(noncases)

# Smoker
noncases$smoker <- 0
noncases$smoker[noncases$tabacq3 == "F"] <- 1

# Choice units (servings/week)
noncases$pm_servings <- noncases$proc_meat/150
noncases$rm_servings <- noncases$red_meat/150
noncases$beef_servings <- noncases$beef/150
noncases$sheep_servings <- noncases$sheep/150
noncases$horse_servings <- noncases$horse/150
noncases$wm_servings <- noncases$white_meat/150
noncases$veal_servings <- noncases$veal/150
noncases$rabbit_servings <- noncases$rabbit/150
noncases$poultry_servings <- noncases$poultry/150
noncases$pork_servings <- noncases$pork/150
noncases$fish_servings <- noncases$fish/150
noncases$sf_servings <- noncases$shellfish/150
noncases$leg_servings <- noncases$legumes/150
noncases$rawveg_servings <- noncases$raw_veg/150
noncases$fruits_servings <- noncases$fruits/150
noncases$eggs_servings <- noncases$eggs/150
noncases$bread_servings <- noncases$bread/150
noncases$rice_servings <- noncases$rice/150
noncases$pasta_servings <- noncases$pasta/150
noncases$cereals_servings <- noncases$cereals/150
noncases$butter_servings <- noncases$butter/150
noncases$cheese_servings <- noncases$cheese/150
noncases$milk_servings <- noncases$milk/150
noncases$yoghurts_servings <- noncases$yoghurts/150
noncases$dp_servings <- noncases$dairy_products/150
noncases$pastries_servings <- noncases$pastries/150
noncases$choco_servings <- noncases$chocolate/150
noncases$jh_servings <- noncases$jams_honey/150
noncases$swdr_servings <- noncases$sweet_drinks/150
noncases$fries_servings <- noncases$fries/150


# Cox model
library("survival")
library("car")

noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model <- coxph(SurvObj ~  pm_servings, data = noncases)
summary(model)

noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
modela <- coxph(SurvObj ~  pm_servings + kcal, data = noncases)
summary(modela)

#################### Non-specified substitution model #################### 
#### Adjusted for total energy intake : log(h(t; x)) = log(h 0 (t)) + a1 food 1 + a2 total energy intake + a3 covariates

### Model 1 was adjusted for total energy intake and unchangeable risk factors: family history cvd and family history hta
## Processed meat
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1 <- coxph(SurvObj ~  pm_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1)

## Fish 
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1a <- coxph(SurvObj ~  fish_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1a)

## Poultry
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1b <- coxph(SurvObj ~  poultry_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1b)

## Beef
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1c <- coxph(SurvObj ~  beef_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1c)

## Legumes
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1d <- coxph(SurvObj ~  leg_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1d)

## Bread
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1e <- coxph(SurvObj ~  bread_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1e)

## Eggs
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1f <- coxph(SurvObj ~  eggs_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1f)

## Fries
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1g <- coxph(SurvObj ~  fries_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1g)

## Cheese
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model1h <- coxph(SurvObj ~  cheese_servings + factor(fam_cvd) + factor(fam_hta) + kcal, data = noncases)
summary(model1h)

### Model 2 was adjusted for total energy intake and changeable risk factors: education, smoking, alcohol, caffeine, physical activity and body mass index
### Processed meat
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2 <- coxph(SurvObj ~ pm_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2)

### Fish
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2a <- coxph(SurvObj ~ fish_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2a)

### Poultry
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2b <- coxph(SurvObj ~ poultry_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2b)

### Beef
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2c <- coxph(SurvObj ~ beef_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2c)

### Legumes
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2d <- coxph(SurvObj ~ leg_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2d)

### Bread
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2e <- coxph(SurvObj ~ bread_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2e)

### Eggs
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2f <- coxph(SurvObj ~ eggs_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2f)

### Fries
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2g <- coxph(SurvObj ~ fries_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2g)

### Cheese
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model2h <- coxph(SurvObj ~ cheese_servings + factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 + kcal, data = noncases)
summary(model2h)

#### Adjusted for total energy intake plus other foods: log(h(t; x)) = log(h 0 (t)) + β1 food 1 + β2 total energy intake + a3 covariates + β4 other foods
### Model 3 was adjusted for total energy intake plus other foods 

# pm, rm, beef, sheep, horse, wm, veal, rabbit, poultry, pork, fish, shellfish, legumes, rawveg
# fruits, eggs, bread, rice, pasta, cereals, butter, cheese, milk, yoghurts, dp
# pastries, chocolate, jams_honey, sweet drinks, fries

### With unchangeable risk factors:
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model3 <- coxph(SurvObj ~  pm_servings + kcal +   
                  factor(fam_cvd) + factor(fam_hta) +
                  sheep_servings + horse_servings + beef_servings +
                  veal_servings + rabbit_servings + pork_servings + poultry_servings + 
                  fish_servings + sf_servings +
                  leg_servings + rawveg_servings + fruits_servings +
                  eggs_servings + bread_servings + cereals_servings +
                  pastries_servings + choco_servings + jh_servings +
                  butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                  swdr_servings + fries_servings
                , data = noncases)
summary(model3)


### With changeable risk factors:
noncases$SurvObj <- with(noncases, Surv(age_debut, age_hta, hypertension))
model4 <- coxph(SurvObj ~ pm_servings +   
                  factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                  sheep_servings + horse_servings + beef_servings +
                  veal_servings + rabbit_servings + pork_servings + poultry_servings + 
                  fish_servings + sf_servings +
                  leg_servings + rawveg_servings + fruits_servings +
                  eggs_servings + bread_servings + cereals_servings +
                  pastries_servings + choco_servings + jh_servings +
                  butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                  swdr_servings + fries_servings
                , data = noncases)
summary(model4)

# Bootstrap 95% CI for replacement

library(boot)

# function to obtain R-Squared from the data

replacement <- function(formula, data, indices) {
  
  d <- data[indices,] # allows boot to select sample
  
  fit <- coxph(formula, data = d)
  
  return(exp(fit$coefficients[2] - fit$coefficients[1]))
  
}

# bootstrapping with 100 replications

# Not specified model
# With unchangeable risk factors
# Fish for processed meat 
results6 <- boot(data = noncases, statistic=replacement,
                R=100, formula= SurvObj ~ pm_servings + fish_servings + kcal+
                  factor(fam_cvd) + factor(fam_hta))
results6
boot.ci(boot.out = results6, type = "norm")

# Poultry for processed meat
results6a <- boot(data = noncases, statistic=replacement,
                 R=100, formula= SurvObj ~ pm_servings + poultry_servings + kcal+
                   factor(fam_cvd) + factor(fam_hta))
results6a
boot.ci(boot.out = results6a, type = "norm")

# Beef for processed meat
results6b <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + beef_servings + kcal+
                    factor(fam_cvd) + factor(fam_hta))
results6b
boot.ci(boot.out = results6b, type = "norm")

# Legumes for processed meat
results6c <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + leg_servings + kcal+
                    factor(fam_cvd) + factor(fam_hta))
results6c
boot.ci(boot.out = results6c, type = "norm")

# Bread for processed meat
results6d <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + bread_servings + kcal+
                    factor(fam_cvd) + factor(fam_hta))
results6d
boot.ci(boot.out = results6d, type = "norm")

# Eggs for processed meat
results6e <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + eggs_servings + kcal+
                    factor(fam_cvd) + factor(fam_hta))
results6e
boot.ci(boot.out = results6e, type = "norm")

# Fries for processed meat
results6f <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + fries_servings + kcal+
                    factor(fam_cvd) + factor(fam_hta))
results6f
boot.ci(boot.out = results6f, type = "norm")

# Cheese for processed meat
results6g <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + cheese_servings + kcal+
                    factor(fam_cvd) + factor(fam_hta))
results6g
boot.ci(boot.out = results6g, type = "norm")

# With changeable risk factors
# Fish for processed meat 
results7 <- boot(data = noncases, statistic=replacement,
                 R=100, formula= SurvObj ~ pm_servings + fish_servings + kcal+
                   factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7
boot.ci(boot.out = results7, type = "norm")

# Poultry for processed meat
results7a <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + poultry_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7a
boot.ci(boot.out = results7a, type = "norm")

# Beef for processed meat
results7b <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + beef_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7b
boot.ci(boot.out = results7b, type = "norm")

# Legumes for processed meat
results7c <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + leg_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7c
boot.ci(boot.out = results7c, type = "norm")

# Bread for processed meat
results7d <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + bread_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7d
boot.ci(boot.out = results7d, type = "norm")

# Eggs for processed meat
results7e <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + eggs_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7e
boot.ci(boot.out = results7e, type = "norm")

# Fries for processed meat
results7f <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + fries_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7f
boot.ci(boot.out = results7f, type = "norm")

# Cheese for processed meat
results7g <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + cheese_servings + kcal+
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3)
results7g
boot.ci(boot.out = results7g, type = "norm")


# Specified model
# with changeable risk factors

# Fish for processed meat
results8 <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + fish_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    eggs_servings + cereals_servings + bread_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results8
boot.ci(boot.out = results8, type = "norm")

# Poultry for processed meat

results8a <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + poultry_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + beef_servings + 
                    veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results8a
boot.ci(boot.out = results8a, type = "norm")

# Beef for processed meat

results8b <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + beef_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + 
                    veal_servings + rabbit_servings + pork_servings + poultry_servings + 
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results8b
boot.ci(boot.out = results8b, type = "norm")

# Legumes for processed meat

results8c <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + leg_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + beef_servings + 
                    veal_servings + rabbit_servings + pork_servings + poultry_servings +
                    fish_servings + sf_servings +
                    rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results8c
boot.ci(boot.out = results8c, type = "norm")

# Bread for processed meat
results8d <- boot(data = noncases, statistic=replacement,
                   R=100, formula= SurvObj ~ pm_servings + bread_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                   sheep_servings + horse_servings + beef_servings + 
                   poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                   fish_servings + sf_servings +
                   leg_servings + rawveg_servings + fruits_servings +
                   eggs_servings + cereals_servings +
                   pastries_servings + choco_servings + jh_servings +
                   butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                   swdr_servings + fries_servings)
results8d
boot.ci(boot.out = results8d, type = "norm")

# Eggs for processed meat

results8e <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + eggs_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results8e
boot.ci(boot.out = results8e, type = "norm")

# Fries for processed meat
results8f <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + fries_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings)
results8f
boot.ci(boot.out = results8f, type = "norm")

# Cheese for processed meat
results8g <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + cheese_servings + kcal +
                    factor(bacfemme2) + factor(smoker) + alcool + cafeine + TotalAPQ3 + imcq3 +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results8g
boot.ci(boot.out = results8g, type = "norm")


# with unchangeable risk factors
# Fish for processed meat
results9 <- boot(data = noncases, statistic=replacement,
                 R=100, formula= SurvObj ~ pm_servings + fish_servings + kcal +
                   factor(fam_cvd) + factor(fam_hta) +
                   sheep_servings + horse_servings + beef_servings + 
                   poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                   sf_servings +
                   leg_servings + rawveg_servings + fruits_servings +
                   eggs_servings + cereals_servings + bread_servings +
                   pastries_servings + choco_servings + jh_servings +
                   butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                   swdr_servings + fries_servings)
results9
boot.ci(boot.out = results9, type = "norm")

# Poultry for processed meat

results9a <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + poultry_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + beef_servings + 
                    veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results9a
boot.ci(boot.out = results9a, type = "norm")

# Beef for processed meat

results9b <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + beef_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + 
                    veal_servings + rabbit_servings + pork_servings + poultry_servings + 
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results9b
boot.ci(boot.out = results9b, type = "norm")

# Legumes for processed meat

results9c <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + leg_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + beef_servings + 
                    veal_servings + rabbit_servings + pork_servings + poultry_servings +
                    fish_servings + sf_servings +
                    rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results9c
boot.ci(boot.out = results9c, type = "norm")

# Bread for processed meat
results9d <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + bread_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    eggs_servings + cereals_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results9d
boot.ci(boot.out = results9d, type = "norm")

# Eggs for processed meat

results9e <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + eggs_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results9e
boot.ci(boot.out = results9e, type = "norm")

# Fries for processed meat
results9f <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + fries_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + cheese_servings + milk_servings + yoghurts_servings +
                    swdr_servings)
results9f
boot.ci(boot.out = results9f, type = "norm")

# Cheese for processed meat
results9g <- boot(data = noncases, statistic=replacement,
                  R=100, formula= SurvObj ~ pm_servings + cheese_servings + kcal +
                    factor(fam_cvd) + factor(fam_hta) +
                    sheep_servings + horse_servings + beef_servings + 
                    poultry_servings + veal_servings + rabbit_servings + pork_servings +  
                    fish_servings + sf_servings +
                    leg_servings + rawveg_servings + fruits_servings +
                    bread_servings + cereals_servings + eggs_servings +
                    pastries_servings + choco_servings + jh_servings +
                    butter_servings + milk_servings + yoghurts_servings +
                    swdr_servings + fries_servings)
results9g
boot.ci(boot.out = results9g, type = "norm")

