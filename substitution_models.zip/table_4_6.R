# Import diabetes data
diab <- read.csv("data_diabetes.csv")
noncases <- subset(diab, prev_diab == 0)

# Smoker
noncases$smoker <- 0
noncases$smoker[noncases$tabacq3 == "F"] <- 1

# Choice units (servings/week)
noncases$pm_ser <- noncases$proc_meat/150
noncases$rm_ser <- noncases$red_meat/150
noncases$wm_ser <- noncases$white_meat/150
noncases$fish_ser <- noncases$fish/150
noncases$sf_ser <- noncases$shellfish/150
noncases$leg_ser <- noncases$legumes/150
noncases$pot_ser <- noncases$potatoes/150
noncases$fries_ser <- noncases$fries/150
noncases$eggs_ser <- noncases$eggs/150
noncases$rice_ser <- noncases$rice/150
noncases$ cer_ser <- noncases$cereals/150
noncases$dp_ser <- noncases$dairy_products/150

# Cox model
library("survival")
library("car")

################################# Nonspecified substitution model ##################################
# Model 1 was adjusted for total energy intake
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1 <- coxph(SurvObj ~  pm_ser + kcal, data = noncases)
summary(model1)

# Model 2 was adjusted adjust as M1 and for unmodified & modified risk factors
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2 <- coxph(SurvObj ~  pm_ser + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2)

# Model 3 was adjusted adjust as M2 and imcq3
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3 <- coxph(SurvObj ~  pm_ser + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3)

# Model 4: was adjusted adjust as M3 and red meat, white meat, fish, shellfish, legumes, potatoes, fries, eggs, rice, cereals and dairy products
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4 <- coxph(SurvObj ~  pm_ser + kcal + fam_cvd + fam_hta + alcool + cafeine + factor(smoker) + factor(bacfemme2) + TotalAPQ3 + imcq3 +
                  rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + cer_ser + dp_ser, data = noncases)
summary(model4)

################################# Specified substitution model ##################################
###################### Model 1 was adjusted for total energy intake ######################
# Unprocessed red meat for processed meat 
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1a <- coxph(SurvObj ~  pm_ser +  rm_ser + kcal, data = noncases)
summary(model1a)
# Boostrapping
library(boot)
# function to obtain R-Squared from the data
replacement <- function(formula, data, indices) {
  
  d <- data[indices,] # allows boot to select sample
  
  fit <- coxph(formula, data = d)
  
  return(exp(fit$coefficients[2] - fit$coefficients[1]))
  
}
boot1a <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~ pm_ser +  rm_ser + kcal)
boot1a
boot.ci(boot.out = boot1a, type = "norm")


# Unprocessed white meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1b <- coxph(SurvObj ~  pm_ser +  wm_ser + kcal, data = noncases)
summary(model1b)
# Bootstrapping
boot1b <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~ pm_ser +  wm_ser + kcal)
boot1b
boot.ci(boot.out = boot1b, type = "norm")

# Fish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1c <- coxph(SurvObj ~  pm_ser +  fish_ser + kcal, data = noncases)
summary(model1c)
# Boostrapping
boot1c <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~  pm_ser +  fish_ser + kcal)
boot1c
boot.ci(boot.out = boot1b, type = "norm")

# Shellfish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1d <- coxph(SurvObj ~  pm_ser +  sf_ser + kcal, data = noncases)
summary(model1d)
# Boostrapping
boot1d <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~  pm_ser +  sf_ser + kcal)
boot1d
boot.ci(boot.out = boot1b, type = "norm")

# Legumes for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1e <- coxph(SurvObj ~  pm_ser +  leg_ser + kcal, data = noncases)
summary(model1e)
# Boostrapping
boot1e <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~  pm_ser +  leg_ser + kcal)
boot1e
boot.ci(boot.out = boot1e, type = "norm")

# Potatoes for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1f <- coxph(SurvObj ~  pm_ser +  pot_ser + kcal, data = noncases)
summary(model1e)
# Boostrapping
boot1f <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~  pm_ser +  pot_ser + kcal)
boot1f
boot.ci(boot.out = boot1f, type = "norm")

# Fies for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1g <- coxph(SurvObj ~  pm_ser +  fries_ser + kcal, data = noncases)
summary(model1e)
# Boostrapping
boot1g <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~  pm_ser +  fries_ser + kcal)
boot1g
boot.ci(boot.out = boot1g, type = "norm")

# Eggs for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1h <- coxph(SurvObj ~  pm_ser +  eggs_ser + kcal, data = noncases)
summary(model1h)
# Boostrapping
boot1h <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~ pm_ser +  eggs_ser + kcal)
boot1h
boot.ci(boot.out = boot1h, type = "norm")

# Rice for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1i <- coxph(SurvObj ~  pm_ser +  rice_ser + kcal, data = noncases)
summary(model1i)
# Boostrapping
boot1i <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~ pm_ser +  rice_ser + kcal)
boot1i
boot.ci(boot.out = boot1i, type = "norm")

# Cereals for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1j <- coxph(SurvObj ~  pm_ser +  cer_ser + kcal, data = noncases)
summary(model1h)
# Boostrapping
boot1j <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~ pm_ser +  cer_ser + kcal)
boot1j
boot.ci(boot.out = boot1j, type = "norm")

# Dairy products for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model1k <- coxph(SurvObj ~  pm_ser +  dp_ser + kcal, data = noncases)
summary(model1k)
# Boostrapping
library(boot)
# function to obtain R-Squared from the data
boot1k <- boot(data = noncases, statistic=replacement,
               R=100, formula= SurvObj ~  pm_ser +  dp_ser + kcal)
boot1k
boot.ci(boot.out = boot1k, type = "norm")


################ Model 2 was adjusted as M1 and for unmodified & modified risk factors ############################
# Unprocessed red meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2a <- coxph(SurvObj ~  pm_ser + rm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2a)
# Boostrapping
boot2a <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + rm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2a
boot.ci(boot.out = boot2a, type = "norm")

# Unprocessed white meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2b <- coxph(SurvObj ~  pm_ser + wm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2b)
# Boostrapping
boot2b <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + wm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2b
boot.ci(boot.out = boot2b, type = "norm")

# Fish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2c <- coxph(SurvObj ~  pm_ser + fish_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2c)
# Boostrapping
boot2c <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + fish_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2c
boot.ci(boot.out = boot2c, type = "norm")

# Shellfish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2d <- coxph(SurvObj ~  pm_ser + sf_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2d)
# Boostrapping
boot2d <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + sf_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2d
boot.ci(boot.out = boot2d, type = "norm")

# Legumes for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2e <- coxph(SurvObj ~  pm_ser + leg_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2e)
# Boostrapping
boot2e <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + leg_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2e
boot.ci(boot.out = boot2e, type = "norm")

# Potatoes for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2f <- coxph(SurvObj ~  pm_ser + pot_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2f)
# Boostrapping
boot2f <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + pot_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2f
boot.ci(boot.out = boot2f, type = "norm")

# Fries for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2g <- coxph(SurvObj ~  pm_ser + fries_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2g)
# Boostrapping
boot2g <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + fries_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2g
boot.ci(boot.out = boot2g, type = "norm")

# Eggs for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2h <- coxph(SurvObj ~  pm_ser + eggs_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2h)
# Boostrapping
boot2h <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + eggs_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2h
boot.ci(boot.out = boot2h, type = "norm")

# Rice for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2i <- coxph(SurvObj ~  pm_ser + rice_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2i)
# Boostrapping
boot2i <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + rice_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2i
boot.ci(boot.out = boot2i, type = "norm")

# Cereals for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2j <- coxph(SurvObj ~  pm_ser + cer_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2j)
# Boostrapping
boot2j <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + cer_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2j
boot.ci(boot.out = boot2j, type = "norm")

# Diary products for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model2k <- coxph(SurvObj ~  pm_ser + dp_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3, data = noncases)
summary(model2k)
# Boostrapping
boot2k <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + dp_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3)
boot2k
boot.ci(boot.out = boot2k, type = "norm")


################ Model 3 was adjusted as M2 and bmi ############################
# Unprocessed red meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3a <- coxph(SurvObj ~  pm_ser + rm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3a)
# Boostrapping
boot3a <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + rm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3a
boot.ci(boot.out = boot3a, type = "norm")

# Unprocessed white meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3b <- coxph(SurvObj ~  pm_ser + wm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3b)
# Boostrapping
boot3b <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + wm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3b
boot.ci(boot.out = boot3b, type = "norm")

# Fish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3c <- coxph(SurvObj ~  pm_ser + fish_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3c)
# Boostrapping
boot3c <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + fish_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3c
boot.ci(boot.out = boot3c, type = "norm")

# Shellfish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3d <- coxph(SurvObj ~  pm_ser + sf_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3d)
# Boostrapping
boot3d <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + sf_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3d
boot.ci(boot.out = boot3d, type = "norm")

# Legumes for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3e <- coxph(SurvObj ~  pm_ser + leg_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3e)
# Boostrapping
boot3e <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + leg_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3e
boot.ci(boot.out = boot3e, type = "norm")

# Potatoes for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3f <- coxph(SurvObj ~  pm_ser + pot_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3f)
# Boostrapping
boot3f <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + pot_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3f
boot.ci(boot.out = boot3f, type = "norm")

# Fries for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3g <- coxph(SurvObj ~  pm_ser + fries_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3g)
# Boostrapping
boot3g <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + fries_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3g
boot.ci(boot.out = boot3g, type = "norm")

# Eggs for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3h <- coxph(SurvObj ~  pm_ser + eggs_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3h)
# Boostrapping
boot3h <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + eggs_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3h
boot.ci(boot.out = boot3h, type = "norm")

# Rice for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3i <- coxph(SurvObj ~  pm_ser + rice_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3i)
# Boostrapping
boot3i <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + rice_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3i
boot.ci(boot.out = boot3i, type = "norm")

# Cereals for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3j <- coxph(SurvObj ~  pm_ser + cer_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3j)
# Boostrapping
boot3j <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + cer_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3j
boot.ci(boot.out = boot3j, type = "norm")

# Diary products for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model3k <- coxph(SurvObj ~  pm_ser + dp_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3, data = noncases)
summary(model3k)
# Boostrapping
boot3k <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + dp_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3)
boot3k
boot.ci(boot.out = boot3k, type = "norm")

################ Model 4 was adjusted as M3 and foods ############################
# Unprocessed red meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4a <- coxph(SurvObj ~  pm_ser + rm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                   rice_ser + cer_ser + dp_ser, data = noncases)
summary(model4a)
# Boostrapping
boot4a <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + rm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4a
boot.ci(boot.out = boot4a, type = "norm")

# Unprocessed white meat for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4b <- coxph(SurvObj ~  pm_ser + wm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4b)
# Boostrapping
boot4b <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + wm_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4b
boot.ci(boot.out = boot4b, type = "norm")

# Fish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4c <- coxph(SurvObj ~  pm_ser + fish_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4c)
# Boostrapping
boot4c <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + fish_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4c
boot.ci(boot.out = boot4c, type = "norm")

# Shellfish for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4d <- coxph(SurvObj ~  pm_ser + sf_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4d)
# Boostrapping
boot4d <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + sf_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + leg_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4d
boot.ci(boot.out = boot4d, type = "norm")

# Legumes for processed meat
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4e <- coxph(SurvObj ~  pm_ser + leg_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4e)
# Boostrapping
boot4e <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + leg_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + pot_ser + fries_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4e
boot.ci(boot.out = boot4e, type = "norm")

# Potatoes for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4f <- coxph(SurvObj ~  pm_ser + pot_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + fries_ser + eggs_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4f)
# Boostrapping
boot4f <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + pot_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + fries_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4f
boot.ci(boot.out = boot4f, type = "norm")

# Fries for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4g <- coxph(SurvObj ~  pm_ser + fries_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + eggs_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4g)
# Boostrapping
boot4g <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + fries_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + eggs_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4g
boot.ci(boot.out = boot4g, type = "norm")

# Eggs for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4h <- coxph(SurvObj ~  pm_ser + eggs_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + rice_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4h)
# Boostrapping
boot4h <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + eggs_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + rice_ser + 
                 cer_ser + dp_ser)
boot4h
boot.ci(boot.out = boot4h, type = "norm")

# Rice for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4i <- coxph(SurvObj ~  pm_ser + rice_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                   cer_ser + dp_ser, data = noncases)
summary(model4i)
# Boostrapping
boot4i <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + rice_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                 cer_ser + dp_ser)
boot4i
boot.ci(boot.out = boot4i, type = "norm")

# Cereals for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4j <- coxph(SurvObj ~  pm_ser + cer_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                   rice_ser + dp_ser, data = noncases)
summary(model4j)
# Boostrapping
boot4j <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + cer_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                 rice_ser + dp_ser)
boot4j
boot.ci(boot.out = boot4j, type = "norm")

# Diary products for PM
noncases$SurvObj <- with(noncases, Surv(ageq3, age_diab, diabete))
model4k <- coxph(SurvObj ~  pm_ser + dp_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                   factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                   rice_ser + cer_ser, data = noncases)
summary(model4k)
# Boostrapping
boot4k <- boot(data = noncases, statistic=replacement,
               R=100, formula = SurvObj ~  pm_ser + dp_ser + kcal + factor(fam_cvd) + factor(fam_hta) + alcool + cafeine + factor(smoker) + 
                 factor(bacfemme2) + TotalAPQ3 + imcq3 + rm_ser + wm_ser + fish_ser + sf_ser + leg_ser + pot_ser + fries_ser + eggs_ser + 
                 rice_ser + cer_ser)
boot4k
boot.ci(boot.out = boot4k, type = "norm")



